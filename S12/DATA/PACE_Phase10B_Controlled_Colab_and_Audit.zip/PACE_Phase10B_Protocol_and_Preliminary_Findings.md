# PACE Phase 10B — Controlled Multi-Seed Algorithm Comparison

**Status: COLAB EXPERIMENT READY; TEN-SEED RESULTS NOT YET EXECUTED.** This is an **analysis-only** deliverable. No manuscript, source supplementary or reviewer-response file was modified.

## Why the previous two-seed comparison was not definitive

1. The fixed-weight GA evaluated 9,309 and 9,321 unique sequences; NSGA-II evaluated 10,269 and 10,321. Thus the unique prediction budget was unequal despite identical nominal population and generation settings.
2. The fixed-weight GA selected its 20 leads from its entire search archive. NSGA-II selected its final leads from the final generation's population. These are different post-selection populations.
3. Only two paired seeds (7 and 29) were available.
4. The six-dimensional Pareto problem produced a very large first front, potentially weakening selection discrimination.

## New retrospective diagnostic from the existing two-seed outputs

A reproducible, exact three-objective minimization hypervolume calculation applied to each previous selected 20-lead library. Objectives: mean log10 MIC, worst-pathogen log10 MIC and negative log10 selectivity. The **common fixed reference** is [log10(32), log10(32), -1].

| Seed | Fixed-weight GA HV | NSGA-II HV |
|---|---:|---:|
| 7 | 1.345897 | 1.354547 |
| 29 | 1.198120 | 1.502041 |

Higher hypervolume indicates broader favorable *predicted* coverage of these three objectives under the specified common reference. These numbers **do not establish algorithmic superiority** because the prior lead-selection and unique-evaluation budgets were not matched, only two seeds exist, and the metric does not account for novelty/recognition. Reproducible code and raw outputs are included.

## Controlled Phase 10B protocol

- Both algorithms evaluate **exactly 9,000 distinct peptide sequences per seed**; previously cached predictions still count toward each algorithm's independent unique-evaluation budget.
- Ten paired seeds: 7, 29, 41, 53, 67, 79, 97, 113, 131 and 149.
- Shared initial populations (same random seed), peptide generator, crossover/mutation functions, pretrained/retrained PACE models, and fitness/constraint calculations.
- Fixed GA: full original scalar PACE objective. NSGA-II: four objectives [mean predicted log MIC, worst predicted log MIC, negative predicted log selectivity, known-sequence 3-mer similarity], with AMP probability as feasibility constraint and the same physical constraints.
- Same **entire archive** available to both algorithms' lead-selection procedure, not final population for one and archive for the other.
- Two common post-selection policies for both algorithms: (a) scalar fitness ranking + 3-mer diversity; (b) four-objective Pareto crowding + common fallback + 3-mer diversity.
- Full-archive three-objective hypervolume, non-dominated archive size, predicted MIC and selectivity, AMP probability, known-sequence similarity, within-library diversity, and mean length. Paired seed differences and bootstrap intervals are generated from the ten paired seeds.
- The equal budget is measured as **unique scored sequences**, not 45 fixed generations (the evolutionary histories may stop at different generations when reaching 9,000).
- Full scored sequence archives saved for independent verification. Input Phase 8 ZIP SHA-256 is verified before fitting/reusing the original PACE predictor family.

## Implementation and validation checks

- All Python code and Colab notebook cells pass `ast.parse`/Python compilation.
- The code for scalar GA, NSGA-II constrained nondominated sorting/crowding, full-archive selection under both policies, and hypervolume passed a **synthetic smoke test**. Mock predictor outputs are strictly unit tests and are not biological findings.
- **The complete ten-seed original-model experiment has not been run in this environment.** It must be executed on Colab and its generated output ZIP independently audited before reviewer-facing conclusions.
- The source Phase 8 results ZIP is the only externally uploaded input required by the standalone notebook. It does not require the original reproducibility ZIP or the old Phase 9 ZIP.

## Scientific limitations

All MIC, HC50 and selectivity values are predictions. Shared prediction-model biases affect both optimizers. No antimicrobial or hemolysis wet-lab testing was done. The retrospectively selected comparison does not substitute for prospective validation or an independent generative-design benchmark.
