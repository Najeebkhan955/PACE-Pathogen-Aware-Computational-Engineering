PACE Phase 10B ANALYSIS-ONLY PACKAGE

Use PACE_Phase10B_Controlled_Colab.ipynb in Google Colab.
Upload PACE_Phase8_ESM2_results.zip when the notebook prompts.
Run the cells in order (CPU or GPU works; the actual workload is tree-model heavy).
The result PACE_Phase10B_Controlled_Results.zip is created after 10 paired seeds.
Upload that ZIP in the conversation for independent verification.
No manuscript or author supplementary files are changed.

The report and retrospective selected-20 HV calculation are included.
Full 10-seed results are NOT precomputed; do not cite them as completed.
