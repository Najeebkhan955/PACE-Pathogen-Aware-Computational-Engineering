import importlib.util, numpy as np
from pathlib import Path
P=Path('/mnt/data/pace_phase10b_analysis/PACE_Phase10B_Controlled_Runner.py')
spec=importlib.util.spec_from_file_location('controlled',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.OUT10B=Path('/mnt/data/pace_phase10b_analysis/smoke_outputs');m.OUT10B.mkdir(exist_ok=True)
m.cache={};m.UNIQUE_BUDGET=300;m.POP10B=48;m.GEN_MAX10B=18
AA=list('ADEFGHIKLNPQRSTVWY')
def random_seq(rng):return ''.join(rng.choice(AA,int(rng.integers(12,20))))
def mutate(s,rng):
 l=list(s);l[int(rng.integers(len(l)))]=str(rng.choice(AA));return ''.join(l)
def crossover(a,b,rng):
 l=min(len(a),len(b));pt=int(rng.integers(2,l-1));return a[:pt]+b[pt:]
def pair_sim(s,t):
 a={s[i:i+3] for i in range(len(s)-2)};b={t[i:i+3] for i in range(len(t)-2)};return len(a&b)/len(a|b)
def get_scores(seq):
 for s in seq:
  if s in m.cache:continue
  asp=s.count('K')+s.count('R');mlen=len(s)
  p=.92+.06*min(asp/5.,1);mm=.45-.012*asp+.005*(mlen-15);worst=mm+.3;ti=1.3+.02*asp
  m.cache[s]=dict(sequence=s,p_amp=p,mic_mean=mm,mic_worst=worst,hc50=mm+ti,ti=ti,sim=.1+pair_sim(s,'AAAAAAAAAAAAAAA'),charge=asp,length=mlen)
 return [m.cache[s] for s in seq]
def fitness(v,arm):
 return 2*v['p_amp']-v['mic_mean']-.5*v['mic_worst']+.6*v['ti']-.35*max(0,abs(v['charge']-6)-3.)
m.random_seq=random_seq;m.mutate=mutate;m.crossover=crossover;m.pair_sim=pair_sim;m.get_scores=get_scores;m.fitness=fitness
f,h=m.run_scalar10b(7,budget=300,popsize=48,maxgens=18)
n,g=m.run_nsga10b(7,budget=300,popsize=48,maxgens=18)
print('scalar, nsga',len(f),len(n),'hist',len(h),len(g))
for arr in (f,n):
  print('HV',m.hv3_10b(arr),'nfront',len(m.pareto_front10b(arr)[0]));
  for policy in ['scalar','pareto']:
   seq,detail=m.common_leads10b(arr,policy)
   print(policy,len(seq),detail,'pwsimmax',max(m.pair_sim(a,b) for i,a in enumerate(seq) for b in seq[i+1:]) if len(seq)>1 else 0)
assert len(f)==len(n)==300
