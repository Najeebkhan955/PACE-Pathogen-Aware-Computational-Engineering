"""PACE Phase 10B: controlled fixed-weight GA versus four-objective NSGA-II.
This module expects the Phase 9 refitted predictor functions and data (get_scores,
cache, random_seq, mutate, crossover, pair_sim, fitness) in the same runtime.
All outputs are ANALYSIS-ONLY; user manuscript and supplementary files untouched.
"""
import csv, json, time, hashlib, zipfile, math
from pathlib import Path
import numpy as np

OUT10B=Path('/content/pace_phase10b_colab')
OUT10B.mkdir(exist_ok=True,parents=True)
SEEDS_10B=(7,29,41,53,67,79,97,113,131,149)
UNIQUE_BUDGET=9000
POP10B=240
GEN_MAX10B=45
REF10B=np.array([np.log10(32),np.log10(32),-1.0],dtype=float)
TOL10B=1e-11

def feasible10b(v):
    return v['p_amp']>=.9 and v['mic_worst']<=REF10B[1] and v['ti']>=1.0 and v['sim']<.55

def obj10b(v):
    # P(AMP) is a feasibility constraint, and excessive charge is soft penalized
    # in scalar GA. NSGA-II trades predicted potency, selectivity and novelty.
    return [v['mic_mean'],v['mic_worst'],-v['ti'],v['sim']]

def cv10b(v):
    return max(0.,.9-v['p_amp']) + max(0.,v['mic_worst']-REF10B[1])+max(0.,1-v['ti'])+max(0.,v['sim']-.55)

def evaluate10b(pop,archive,budget=UNIQUE_BUDGET):
    # Predicted sequences already in another algorithm's global cache STILL
    # count against this run's independent unique-sequence budget.
    fresh=list(dict.fromkeys(s for s in pop if s not in archive))
    n=max(0,budget-len(archive));new=fresh[:n]
    if new:
        get_scores(new)
        archive.update(new)
    return [s for s in pop if s in archive],len(new)

def rank_crowd10b(pop):
    # Small set (<=480); Deb-style constrained domination and standard crowding.
    rec=get_scores(pop);X=np.asarray([obj10b(v) for v in rec],float)
    cv=np.asarray([cv10b(v) for v in rec]);n=len(pop)
    f=cv<=TOL10B
    d=np.all(X[:,None,:]<=X[None,:,:]+TOL10B,axis=2)&np.any(X[:,None,:]<X[None,:,:]-TOL10B,axis=2)
    dom=np.where(f[:,None]&~f[None,:],True,np.where(~f[:,None]&f[None,:],False,
           np.where(~f[:,None]&~f[None,:],cv[:,None]<cv[None,:]-TOL10B,d)))
    np.fill_diagonal(dom,False)
    rank=np.full(n,-1,dtype=int);remain=np.ones(n,dtype=bool);fronts=[];idx=0
    while remain.any():
        ii=np.flatnonzero(remain)
        counts=np.sum(dom[np.ix_(ii,ii)],axis=0)
        front=ii[counts==0]
        if not len(front):raise ValueError('Non-dominated ranking cycle')
        rank[front]=idx;remain[front]=False;fronts.append(front);idx+=1
    crowd=np.zeros(n,dtype=float)
    for front in fronts:
        if len(front)<=2:crowd[front]=np.inf;continue
        for j in range(X.shape[1]):
            order=front[np.argsort(X[front,j],kind='stable')]
            spread=X[order[-1],j]-X[order[0],j]
            if spread>TOL10B:
                crowd[order[0]]=np.inf;crowd[order[-1]]=np.inf
                crowd[order[1:-1]]+=(X[order[2:],j]-X[order[:-2],j])/spread
    return rank,crowd,fronts

def choose_nsga10b(pop,k=POP10B):
    pop=list(dict.fromkeys(pop));r,c,fronts=rank_crowd10b(pop);picked=[]
    for front in fronts:
        if len(picked)+len(front)<=k:picked.extend(front.tolist())
        else:
            order=front[np.argsort(-c[front],kind='stable')]
            picked.extend(order[:k-len(picked)].tolist());break
    return [pop[i] for i in picked]

def tournament10b(pop,rank,crowd,rng):
    i,j=rng.integers(0,len(pop),size=2)
    if rank[i]!=rank[j]:return pop[i if rank[i]<rank[j] else j]
    if crowd[i]!=crowd[j]:return pop[i if crowd[i]>crowd[j] else j]
    return pop[int(i if rng.random()<.5 else j)]

def run_scalar10b(seed,budget=UNIQUE_BUDGET,popsize=POP10B,maxgens=GEN_MAX10B):
    rng=np.random.default_rng(seed);pop=[random_seq(rng) for _ in range(popsize)];seen=set();hist=[]
    for gen in range(1,maxgens+1):
        scored,new=evaluate10b(pop,seen,budget)
        if not scored:break
        rec=get_scores(scored);ff=np.asarray([fitness(v,'full') for v in rec]);ix=np.argsort(-ff,kind='stable')
        ranked=[scored[i] for i in ix];ordered_f=ff[ix]
        hist.append(dict(algorithm='Fixed-weight GA',seed=seed,generation=gen,unique_evaluated=len(seen),
            feasible_seen=sum(feasible10b(cache[s]) for s in seen),best_fitness=float(ordered_f[0]),
            population_mean_mic=float(np.mean([v['mic_mean'] for v in rec]))))
        if len(seen)==budget or gen==maxgens:break
        nxt=ranked[:min(24,len(ranked))]
        while len(nxt)<popsize:
            def tourn():
                chosen=rng.integers(0,len(ranked),size=3)
                return ranked[int(chosen[np.argmax(ordered_f[chosen])])]
            s=crossover(tourn(),tourn(),rng) if rng.random()<.6 else tourn()
            if rng.random()<.9:s=mutate(s,rng)
            if 12<=len(s)<=30:nxt.append(s)
        pop=nxt
    return seen,hist

def run_nsga10b(seed,budget=UNIQUE_BUDGET,popsize=POP10B,maxgens=GEN_MAX10B):
    rng=np.random.default_rng(seed);pop=[random_seq(rng) for _ in range(popsize)];seen=set();hist=[]
    pop,_=evaluate10b(pop,seen,budget)
    for gen in range(1,maxgens+1):
        rank,crowd,fronts=rank_crowd10b(pop)
        hist.append(dict(algorithm='NSGA-II',seed=seed,generation=gen,unique_evaluated=len(seen),
             feasible_seen=sum(feasible10b(cache[s]) for s in seen),first_front=len(fronts[0]),
             feasible_population=sum(feasible10b(cache[s]) for s in pop)))
        if len(seen)==budget or gen==maxgens:break
        children=[]
        while len(children)<popsize:
            a=tournament10b(pop,rank,crowd,rng)
            s=crossover(a,tournament10b(pop,rank,crowd,rng),rng) if rng.random()<.6 else a
            if rng.random()<.9:s=mutate(s,rng)
            if 12<=len(s)<=30:children.append(s)
        children,_=evaluate10b(children,seen,budget)
        if len(seen)==budget:break
        pop=choose_nsga10b(pop+children,popsize)
        while len(pop)<popsize:
            s=random_seq(rng)
            if s not in pop:
                # Enforce budget when refreshing a collapsed population
                s2,_=evaluate10b([s],seen,budget)
                if not s2:break
                pop.append(s)
    return seen,hist

def pareto_front10b(strings,indices=(0,1,2,3)):
    # Exact nondominated archive for these four objectives, without quadratic NxN allocation.
    ss=list(strings)
    if not ss:return [],np.empty((0,len(indices)))
    X=np.asarray([obj10b(cache[s]) for s in ss])[:,indices]
    sortkey=tuple(X[:,j] for j in range(len(indices)-1,-1,-1))
    order=np.lexsort(sortkey);front=[]
    for i in order:
        if front:
            # Lexicographic ascending ensures later items cannot dominate previous ones.
            B=X[front]
            if np.any(np.all(B<=X[i]+TOL10B,axis=1) & np.any(B<X[i]-TOL10B,axis=1)):
                continue
            if np.any(np.all(abs(B-X[i])<=TOL10B,axis=1)):
                continue
        front.append(i)
    return [ss[i] for i in front],X[front]

def crowd_front10b(X):
    n,m=X.shape
    c=np.zeros(n,dtype=float)
    if n<=2:return np.full(n,np.inf)
    for j in range(m):
        order=np.argsort(X[:,j],kind='stable');spread=X[order[-1],j]-X[order[0],j]
        if spread>1e-12:
            c[order[0]]=np.inf;c[order[-1]]=np.inf
            c[order[1:-1]]+=(X[order[2:],j]-X[order[:-2],j])/spread
    return c

def common_leads10b(seen,policy):
    feasible=[s for s in seen if feasible10b(cache[s])]
    feasible.sort()
    fallback=0
    if policy=='scalar':order=sorted(feasible,key=lambda s:(-fitness(cache[s],'full'),s))
    elif policy=='pareto':
        front,X=pareto_front10b(feasible)
        crowd=crowd_front10b(X)
        order=[front[i] for i in sorted(range(len(front)),key=lambda i:(-crowd[i],-fitness(cache[front[i]],'full'),front[i]))]
        remain=sorted(set(feasible)-set(front),key=lambda s:(-fitness(cache[s],'full'),s))
        order+=remain
    else:raise ValueError(policy)
    frontset=set(order[:len(front)]) if policy=='pareto' else set()
    leads=[]
    for s in order:
        if all(pair_sim(s,t)<=.45 for t in leads):
            leads.append(s)
            if policy=='pareto' and s not in frontset:fallback+=1
        if len(leads)>=20:break
    return leads, {'n_feasible':len(feasible),'n_selected':len(leads),'pareto_scalar_fallbacks':fallback}

def hv2_10b(P,ref):
    if not len(P):return 0.
    P=P[np.all(P<ref,axis=1)]
    if not len(P):return 0.
    P=P[np.argsort(P[:,0])];best=ref[1];volume=0.
    for i,row in enumerate(P):
        best=min(best,row[1]);nxt=P[i+1,0] if i+1<len(P) else ref[0]
        volume+=max(0.,nxt-row[0])*max(0.,ref[1]-best)
    return float(volume)

def hv3_10b(seen):
    feas=[s for s in seen if feasible10b(cache[s])]
    if not feas:return 0.,0
    front,X=pareto_front10b(feas,indices=(0,1,2))
    X=X[np.all(X<REF10B,axis=1)]
    ux=np.unique(X[:,0]);vol=0.
    for i,x in enumerate(ux):
        nxt=ux[i+1] if i+1<len(ux) else REF10B[0]
        vol+=(nxt-x)*hv2_10b(X[X[:,0]<=x][:,1:],REF10B[1:])
    return float(vol),len(front)

def metrics10b(rows):
    return {
     'mean_predicted_mic_um':float(np.mean([10**v['mic_mean'] for v in rows])),
     'mean_predicted_worst_mic_um':float(np.mean([10**v['mic_worst'] for v in rows])),
     'mean_predicted_selectivity':float(np.mean([10**v['ti'] for v in rows])),
     'mean_amp_probability':float(np.mean([v['p_amp'] for v in rows])),
     'mean_known_3mer_similarity':float(np.mean([v['sim'] for v in rows])),
     'median_pairwise_3mer_similarity':float(np.median([pair_sim(a['sequence'],b['sequence']) for i,a in enumerate(rows) for b in rows[i+1:]])),
     'mean_length':float(np.mean([v['length'] for v in rows]))
    }

def write_csv10b(p,rows):
    if not rows:return
    keys=list(rows[0].keys())
    with open(p,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

def run_one10b(seed):
    output=[];histories=[]
    for name,fn in [('Fixed-weight GA',run_scalar10b),('NSGA-II',run_nsga10b)]:
        t=time.time();archive,hist=fn(seed);histories+=hist
        if len(archive)!=UNIQUE_BUDGET:raise RuntimeError(f'{name} seed {seed}: only {len(archive)} unique evaluated, required {UNIQUE_BUDGET}; increase MAXGENS.')
        hv,nd=hv3_10b(archive)
        feas=[s for s in archive if feasible10b(cache[s])]
        front,_=pareto_front10b(feas)
        for policy in ('scalar','pareto'):
            selected,meta=common_leads10b(archive,policy)
            if len(selected)<20:raise RuntimeError(f'{name}/{seed}/{policy} only {len(selected)} feasible diverse leads')
            rec=[cache[s] for s in selected]
            vals=metrics10b(rec)
            output.append(dict(algorithm=name,seed=seed,selection_policy=policy,unique_evaluated=len(archive),
                     n_feasible=len(feas),n_4d_nondominated_archive=len(front),n_3d_nondominated_archive=nd,
                     hypervolume_3d=hv,pareto_scalar_fallbacks=meta['pareto_scalar_fallbacks'],
                     runtime_seconds=time.time()-t,**vals))
            leadrows=[dict(algorithm=name,seed=seed,selection_policy=policy,rank=i+1,
                    **v,full_fitness=fitness(v,'full'),predicted_geom_mean_MIC_um=10**v['mic_mean'],
                    predicted_worst_MIC_um=10**v['mic_worst'],predicted_selectivity=10**v['ti'])
                 for i,v in enumerate(rec)]
            write_csv10b(OUT10B/f'{name.replace(" ","_")}_{policy}_{seed}_leads.csv',leadrows)
        # Save an entire archive for an audit by third party
        write_csv10b(OUT10B/f'{name.replace(" ","_")}_{seed}_full_archive.csv',
                    [cache[s] for s in sorted(archive)])
        print('Phase10B',name,'seed',seed,'N',len(archive),'hv3',round(hv,5),'elapsed',round(time.time()-t,1),'s',flush=True)
    write_csv10b(OUT10B/f'seed_{seed}_summary.csv',output)
    write_csv10b(OUT10B/f'seed_{seed}_history.csv',histories)
    return output

def aggregate10b():
    import pandas as pd
    paths=sorted(OUT10B.glob('seed_*_summary.csv'))
    if not paths:raise RuntimeError('No seed summaries')
    df=pd.concat([pd.read_csv(p) for p in paths],ignore_index=True)
    assert len(df)==4*len(paths),f'Missing results: {len(df)} records for {len(paths)} seeds'
    df.to_csv(OUT10B/'all_seed_summary.csv',index=False)
    metric_cols=['hypervolume_3d','mean_predicted_mic_um','mean_predicted_worst_mic_um','mean_predicted_selectivity',
                 'mean_amp_probability','mean_known_3mer_similarity','median_pairwise_3mer_similarity']
    rng=np.random.default_rng(2026)
    stats=[]
    for policy in ('scalar','pareto'):
        subset=df[df.selection_policy==policy]
        for met in metric_cols:
            p=subset.pivot(index='seed',columns='algorithm',values=met)
            delta=(p['NSGA-II']-p['Fixed-weight GA']).to_numpy()
            boot=delta[rng.integers(0,len(delta),(10000,len(delta)))].mean(axis=1)
            stats.append(dict(selection_policy=policy,metric=met,n_pairs=len(delta),
                mean_nsga_minus_fixed=float(delta.mean()),median_nsga_minus_fixed=float(np.median(delta)),
                bootstrap95_low=float(np.quantile(boot,.025)),bootstrap95_high=float(np.quantile(boot,.975)),
                note='Paired seeds; exploratory uncertainty, not experimental validation.'))
    pd.DataFrame(stats).to_csv(OUT10B/'paired_seed_bootstrap.csv',index=False)
    meta={'source_phase8_sha256':hashlib.sha256(Path('/content/PACE_Phase8_ESM2_results.zip').read_bytes()).hexdigest(),
          'trained_model_source':'Full Phase 9 refitted PACE 90D models, same 7 prediction models for both optimizers',
          'seeds':list(SEEDS_10B),'unique_evaluation_budget_per_algorithm_per_seed':UNIQUE_BUDGET,
          'population':POP10B,'maximum_generations':GEN_MAX10B,
          'initial_population':'Matched via same seed; same random_seq function, objective-independent',
          'archive_selection':'Both algorithms: all evaluated unique sequences and the identical feasibility/diversity rules',
          'selection_policies':['scalar ranking by original full PACE fitness','4D Pareto crowding then scalar fallback'],
          'Pareto_4D':['mean log10MIC','worst log10MIC','negative log10 selectivity','3mer known-corpus similarity'],
          'NSGA2_constraint_rules':'P(AMP)>=0.9; worst MIC<=32uM; TI>=10; known similarity<0.55',
          'hypervolume_3D_reference':REF10B.tolist(),
          'comparison_scope':'In silico; MIC, hemolysis and selectivity are all predictions, no biological validation',
          'important':'Different numbers of generations are allowed to achieve exactly the same 9000 unique-evaluation budget.'}
    (OUT10B/'protocol_metadata.json').write_text(json.dumps(meta,indent=2))
    out=Path('/content/PACE_Phase10B_Controlled_Results.zip')
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in OUT10B.glob('*'):
            if p.is_file():z.write(p,arcname=p.name)
    print('Phase10B results ready:',out,'bytes',out.stat().st_size,flush=True)
    return out

if __name__=='__main__':
    for sd in SEEDS_10B:
        if (OUT10B/f'seed_{sd}_summary.csv').exists():
            print('Skipping saved seed',sd,flush=True);continue
        run_one10b(sd)
    aggregate10b()
