"""Retrospective 3-objective hypervolume, with shared fixed reference.
Only original two-seed, selection-unmatched archives are available; this is NOT the Phase10B controlled experiment.
"""
from pathlib import Path
import zipfile, io, numpy as np, pandas as pd, json
OUT=Path('/mnt/data/pace_phase10b_analysis')
ROOT=Path('/mnt/data')
z=zipfile.ZipFile(ROOT/'PACE_Phase10_NSGA2_Results.zip')
df=pd.read_csv(z.open('matched_budget_algorithm_comparison_leads.csv'))
# minimization over log mean MIC, log worst MIC, -log selectivity; fixed feasible reference
REFERENCE=np.array([np.log10(32),np.log10(32),-1.0])
LOWER=np.array([-1.5,-1.5,-4.0])
def hv2(P,ref):
    if not len(P):return 0.
    P=np.minimum(np.maximum(P,LOWER[1:]),ref)
    P=P[np.all(P<ref,axis=1)]
    if not len(P):return 0.
    P=P[np.argsort(P[:,0])]
    area=0.;best=ref[1]
    for i,row in enumerate(P):
        best=min(best,row[1]);nxt=P[i+1,0] if i+1<len(P) else ref[0]
        area+=max(0.,nxt-row[0])*max(0.,ref[1]-best)
    return area
def hv3(P,ref=REFERENCE):
    P=np.minimum(np.maximum(P,LOWER),ref)
    P=P[np.all(P<ref,axis=1)]
    if not len(P):return 0.
    unique_x=np.unique(P[:,0]);out=0.
    for i,x in enumerate(unique_x):
        nxt=unique_x[i+1] if i+1<len(unique_x) else ref[0]
        out+=(nxt-x)*hv2(P[P[:,0]<=x][:,1:],ref[1:])
    return float(out)
def nd_count(P):
    return sum(not np.any(np.all(P<=x+1e-12,axis=1)&np.any(P<x-1e-12,axis=1)) for x in P)
results=[]
for (alg,seed),d in df.groupby(['algorithm','seed']):
    P=np.stack([d.mic_mean,d.mic_worst,-d.ti],axis=1)
    results.append({'algorithm':alg,'seed':seed,'n_selected':len(d),'three_objective_hypervolume':hv3(P), 'three_objective_nondominated':nd_count(P),'reference':str(REFERENCE.tolist()),'note':'retrospective selected libraries; unequal evaluation budgets and different selection pools'})
report=pd.DataFrame(results).sort_values(['seed','algorithm'])
report.to_csv(OUT/'retrospective_selected20_hypervolume.csv',index=False)
print(report[['algorithm','seed','three_objective_hypervolume','three_objective_nondominated']].to_string(index=False))
